﻿using System;
using System.Collections.Generic;
using CineUTN.Repos.Models;
using CineUTN.Models;
using Microsoft.EntityFrameworkCore;

namespace CineUTN.Repos;

public partial class CineUTNContext : DbContext
{
    public CineUTNContext()
    {
    }

    public CineUTNContext(DbContextOptions<CineUTNContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Genero> Generos { get; set; }
    public virtual DbSet<Sonido> Sonidos { get; set; }

    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //    => optionsBuilder.UseSqlServer("name=conexion");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
